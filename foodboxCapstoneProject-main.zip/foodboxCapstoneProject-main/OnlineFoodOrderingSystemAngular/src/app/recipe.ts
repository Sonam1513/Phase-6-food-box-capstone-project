export class Recipe {
  public _id:string;
  public dishname:string;
  public quantity:string;
  public price:Number;
  public dishimage:string;
}
