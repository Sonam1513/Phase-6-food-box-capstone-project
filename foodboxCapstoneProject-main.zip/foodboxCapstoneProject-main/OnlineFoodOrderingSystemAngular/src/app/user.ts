export class User {
  public _id:string;
  public name:string;
  public email:string;
  public contact:Number;
  public password:string;
  public role:string;
  public blocked:boolean;
}
