# Online Food Ordering System

This project was generated with  Angular CLI integrated with Backend (Express.js and Mongo DB)


