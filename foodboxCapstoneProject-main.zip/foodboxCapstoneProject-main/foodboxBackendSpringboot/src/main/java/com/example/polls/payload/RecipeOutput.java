package com.example.polls.payload;

public class RecipeOutput {

	int n =1;
	int nModified=1;
	int ok=1;
	public int getN() {
		return n;
	}
	public void setN(int n) {
		this.n = n;
	}
	public int getnModified() {
		return nModified;
	}
	public void setnModified(int nModified) {
		this.nModified = nModified;
	}
	public int getOk() {
		return ok;
	}
	public void setOk(int ok) {
		this.ok = ok;
	}
	
	
	
}
