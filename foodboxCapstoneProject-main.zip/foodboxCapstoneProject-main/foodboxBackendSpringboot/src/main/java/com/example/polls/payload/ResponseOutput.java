package com.example.polls.payload;

public class ResponseOutput {
	
	private Object msg;
	
	

	public ResponseOutput() {
		super();
	}

	public ResponseOutput(Object msg) {
		super();
		this.msg = msg;
	}

	public Object getMsg() {
		return msg;
	}

	public void setMsg(Object msg) {
		this.msg = msg;
	}
	
	

}
