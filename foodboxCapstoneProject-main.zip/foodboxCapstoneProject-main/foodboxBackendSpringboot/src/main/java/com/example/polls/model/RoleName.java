package com.example.polls.model;

public enum  RoleName {
    ROLE_USER,
    ROLE_ADMIN
}
