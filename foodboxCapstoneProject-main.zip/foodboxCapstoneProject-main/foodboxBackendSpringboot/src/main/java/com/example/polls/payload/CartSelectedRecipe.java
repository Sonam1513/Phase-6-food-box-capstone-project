package com.example.polls.payload;

public class CartSelectedRecipe {

}
